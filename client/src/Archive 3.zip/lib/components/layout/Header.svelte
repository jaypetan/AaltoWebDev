<header class="flex items-center bg-primary-100 p-4 mb-6">
  <h1 class="text-xl text-primary-900">Application name</h1>
  <nav class="ml-4">
    <ul class="flex space-x-4">
      <li><a class="anchor" href="/">Home</a></li>
      <li><a class="anchor" href="/courses">Courses</a></li>
    </ul>
  </nav>
</header>