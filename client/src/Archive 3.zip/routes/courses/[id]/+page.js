export function load({ params }) {
    return params;
}
  