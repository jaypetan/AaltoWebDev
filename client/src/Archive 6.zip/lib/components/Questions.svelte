<script>
  import QuestionForm from "./QuestionForm.svelte";
  import QuestionItem from "./QuestionItem.svelte";
  import QuestionList from "./QuestionList.svelte";
</script>

<h1>Questions</h1>

<h2>Add Question</h2>

<QuestionForm />

<h2>Existing Questions</h2>

<QuestionList />