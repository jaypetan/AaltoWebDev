<h1>Welcome!</h1>
<a href="/courses">Courses</a>